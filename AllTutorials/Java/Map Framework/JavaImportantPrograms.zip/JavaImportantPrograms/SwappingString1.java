package JavaImportantPrograms;

public class SwappingString1 {

	public static void main(String[] args) {
		
		String a="java";
		String b="selenium";
		String c;
		
		c=a;
		a=b;
		b=c;
		
		System.out.println("after swapping "+a+" :: "+b);

	}
}
