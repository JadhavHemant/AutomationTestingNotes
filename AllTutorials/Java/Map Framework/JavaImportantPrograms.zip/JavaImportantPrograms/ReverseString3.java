package JavaImportantPrograms;

public class ReverseString3 {

	public static void main(String[] args) {
		String a = "Selenium";

		StringBuffer sb = new StringBuffer(a);
		StringBuffer sb1 = sb.reverse();
		System.out.println(sb1);

	}

}
