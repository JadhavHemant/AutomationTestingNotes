package JavaImportantPrograms;

public class ReverseString4 {

	public static void main(String[] args) {
		String a = "Selenium";

		StringBuilder sb = new StringBuilder(a);
		StringBuilder sb1 = sb.reverse();
		System.out.println(sb1);

	}
}
