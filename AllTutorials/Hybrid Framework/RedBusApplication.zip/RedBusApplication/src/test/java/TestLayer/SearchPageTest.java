package TestLayer;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import BaseLayer.BaseClass;
import PageLayer.SearchPage;

public class SearchPageTest extends BaseClass {
	private static SearchPage searchPage;

	@BeforeTest
	public void setUp() {
		BaseClass.initialization();
	}

	@Test
	public void validateSelectDateFunctionality() throws InterruptedException {
		Thread.sleep(5000);
		searchPage = new SearchPage();
		searchPage.selectDateFunctionality("October 2024", "27");
	}

}
