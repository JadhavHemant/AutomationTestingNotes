package PageLayer;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import BaseLayer.BaseClass;
import UtilityLayer.CalenderClass;
import UtilityLayer.Wait;

public class SearchPage extends BaseClass {

	// calender button
	// @FindBy(id = "onwardCal") ---> redbus

	@FindBy(xpath = "//span[text()='Departure']/following-sibling::p[@class='sc-12foipm-4 czGBLf fswWidgetTitle']")
	private WebElement calender;

	/// month and year
	// @FindBy(xpath = "(//div[@class='DayNavigator__IconBlock-qj8jdz-2
	/// iZpveD'])[2]")
	@FindBy(xpath = "//div[@class='DayPicker-Month']/preceding-sibling::div/descendant::div[@class='DayPicker-Caption']/child::div")
	private WebElement monthAndYear;

	/// next button
	//@FindBy(xpath = "(//div[@class='DayNavigator__IconBlock-qj8jdz-2 iZpveD'])[3]")  --->red bus
	
	@FindBy(xpath="//span[@class='DayPicker-NavButton DayPicker-NavButton--next']")
	private WebElement next;

	// find all dates
	//@FindBys(@FindBy(xpath = "//span[@class='DayTiles__CalendarDaysSpan-sc-1xum02u-1 bwoYtA' or @class='DayTiles__CalendarDaysSpan-sc-1xum02u-1 dkWAbH']"))
	
	@FindBys(@FindBy(xpath="//div[@class='DayPicker-Month']/preceding-sibling::div/descendant::div[@class='DayPicker-Day']/child::p"))
	private List<WebElement> days;

	public SearchPage() {
		PageFactory.initElements(driver, this);
	}

	public void selectDateFunctionality(String monthYear, String date) {
		Wait.click(calender);
		CalenderClass.selectMonthAndYear(monthAndYear, next, monthYear);
		CalenderClass.selectDate(days, date);
	}

}
