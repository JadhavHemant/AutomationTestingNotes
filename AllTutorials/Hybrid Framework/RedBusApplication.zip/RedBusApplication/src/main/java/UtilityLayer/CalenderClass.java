package UtilityLayer;

import java.util.List;

import org.openqa.selenium.WebElement;

import BaseLayer.BaseClass;

public class CalenderClass extends BaseClass {

	// select the expected month and year
	public static void selectMonthAndYear(WebElement monthAndYear, WebElement next, String expectedMonthAndYear) {
		while (true) {
			String actualMonth = monthAndYear.getText();

			if (actualMonth.contains(expectedMonthAndYear)) {
				break;
			} else {
				Wait.click(next);
			}
		}
	}

	// select the expected dates
	public static void selectDate(List<WebElement> listDates, String expectedDate) {
		for (WebElement abc : listDates) {
			String actualDate = abc.getText();

			if (actualDate.equals(expectedDate)) {
				Wait.click(abc);
				break;
			}
		}

	}

}
