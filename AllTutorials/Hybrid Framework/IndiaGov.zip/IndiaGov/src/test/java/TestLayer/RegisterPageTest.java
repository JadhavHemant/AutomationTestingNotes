package TestLayer;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import BaseLayer.BaseClass;
import PageLayer.RegisterPage;

public class RegisterPageTest extends BaseClass {
	private static RegisterPage registerPage;

	@BeforeTest
	public void setUp() {
		BaseClass.initialization();
	}

	@Test
	public void validateCreateAccountFunctionality() {
		registerPage = new RegisterPage();
		registerPage.createAccountFunctionality("rohit@gmail.com", "rohit@gmail.com", "rohit", "Patil", "India",
				"Maharashtra", "909900", 0);
	}

}
