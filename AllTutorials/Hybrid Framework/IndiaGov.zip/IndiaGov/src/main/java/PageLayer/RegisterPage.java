package PageLayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayer.BaseClass;
import UtilityLayer.SelectClass;
import UtilityLayer.Wait;

public class RegisterPage extends BaseClass {

	@FindBy(name = "name")
	private WebElement username;

	@FindBy(name = "mail")
	private WebElement email;

	@FindBy(name = "profile_main[field_first_name][und][0][value]")
	private WebElement firstName;

	@FindBy(name = "profile_main[field_last_name][und][0][value]")
	private WebElement lastName;

	@FindBy(name = "profile_main[field_country][und]")
	private WebElement country;

	@FindBy(name = "profile_main[field_state][und][hierarchical_select][selects][0]")
	private WebElement state;

	@FindBy(name = "profile_main[field_pin_code][und][0][value]")
	private WebElement pincode;

	@FindBy(name = "profile_main[field_education][und]")
	private WebElement education;

	@FindBy(name = "profile_main[field__subscribe_to_our_newslett][und][Yes]")
	private WebElement newLettercheckbox;

	public RegisterPage() {
		PageFactory.initElements(driver, this);
	}

	// create associated method for each and every object repository without
	// entering test data
	public void createAccountFunctionality(String Uname, String Email, String Fname, String Lname, String Country,
			String State, String PinCode, int Education) {
		Wait.sendKeys(username, Uname);
		Wait.sendKeys(email, Email);
		Wait.sendKeys(firstName, Fname);
		Wait.sendKeys(lastName, Lname);

		SelectClass.selectByVisibleText(country, Country);
		SelectClass.selectByVisibleText(state, State);

		Wait.sendKeys(pincode, PinCode);

		SelectClass.selectByIndex(education, Education);

		Wait.click(newLettercheckbox);

	}

}
