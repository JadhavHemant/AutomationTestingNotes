package UtilityLayer;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import BaseLayer.BaseClass;

public class Wait extends BaseClass {

	// check element is displayed or not using explicit wait

	public static WebElement visibilityOfElement(WebElement wb) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		WebElement wb1 = wait.until(ExpectedConditions.visibilityOf(wb));
		return wb1;
	}

	// check element is clickable or not using explicit wait
	public static void click(WebElement wb) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(wb)).click();
	}

	// enter text in text box using Explicit wait
	public static void sendKeys(WebElement wb, String value) {
		Wait.visibilityOfElement(wb).sendKeys(value);
	}


	
	

}
