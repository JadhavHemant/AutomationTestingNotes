package UtilityLayer;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import BaseLayer.BaseClass;

public class SelectClass extends BaseClass {

	// select drop down value using selectByVisibleText() method and before
	// selecting value check elememnt is visible or not

	public static void selectByVisibleText(WebElement wb, String value) {
		WebElement wb1 = Wait.visibilityOfElement(wb);
		Select sel = new Select(wb1);
		sel.selectByVisibleText(value);
	}

	public static void selectByValue(WebElement wb, String value) {
		new Select(Wait.visibilityOfElement(wb)).selectByValue(value);
	}

	public static void selectByIndex(WebElement wb, int index) {
		new Select(Wait.visibilityOfElement(wb)).selectByIndex(index);
	}

	public static void getOptions(WebElement wb) {
		List<WebElement> listWebElement = new Select(Wait.visibilityOfElement(wb)).getOptions();
		for (WebElement abc : listWebElement) {
			System.out.println(abc.getText());
		}
	}

}
