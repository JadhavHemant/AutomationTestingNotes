package UtilityLayer;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import BaseLayer.BaseClass;

public class Screenshot extends BaseClass {

	public static String takeScreenshot(String folderName, String ScreenshotName) {
		String destPath = System.getProperty("user.dir") + "//" + folderName + "//" + DateAndTime.captureCurrentYear()
				+ "//" + DateAndTime.captureCurrentMonthAndYear() + "//" + ScreenshotName
				+ DateAndTime.captureCurrentDateAndTime() + ".png";

		try {
			FileUtils.copyFile(((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE), new File(destPath));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return destPath;
	}

}
