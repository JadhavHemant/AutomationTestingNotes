package UtilityLayer;

import BaseLayer.BaseClass;

public class AlertClass extends BaseClass {

	public static void accept() {
		driver.switchTo().alert().accept();
	}

	public static void dismiss() {
		driver.switchTo().alert().dismiss();
	}

	public static String getText() {
		return driver.switchTo().alert().getText();
	}

	public static void sendKeys(String value) {
		driver.switchTo().alert().sendKeys(value);
	}

}
