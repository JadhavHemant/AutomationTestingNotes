package TestLayer;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import BaseLayer.BaseClass;

public class OrangeHRMTest extends BaseClass {

	@BeforeTest
	public void setUp() {
		BaseClass.initialization();
	}

	@Test(priority = 1)
	public void validateLoginFunctionality() throws InterruptedException {
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[text()= ' Login ']")).click();
		Thread.sleep(2000);
	}

	@Test(priority = 2)
	public void validateHomePageTitle() throws InterruptedException {
		String actualTitle = driver.getTitle();
		Assert.assertEquals(actualTitle, "OrangeHRM");
		Thread.sleep(2000);
	}

	@Test(priority = 3)
	public void validateHomePageUrl() throws InterruptedException {
		boolean actualResult = driver.getCurrentUrl().contains("orange");
		Assert.assertEquals(actualResult, true);
		Thread.sleep(2000);
	}

	@Test(priority = 4)
	public void validatePIMPageUrl() throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='PIM']")).click();

		boolean actualResult = driver.getCurrentUrl().contains("pim");
		Assert.assertEquals(actualResult, true);
		Thread.sleep(2000);
	}

	@Test(priority = 5)
	public void validateAdminPageUrl() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='Admin']")).click();
		Thread.sleep(2000);
		boolean actualResult = driver.getCurrentUrl().contains("facebook");
		Thread.sleep(2000);
		Assert.assertEquals(actualResult, true);
		
	}

	@Test(priority = 6,dependsOnMethods = "validateAdminPageUrl")
	public void validateLeavePageUrl() throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='Leave']")).click();

		boolean actualResult = driver.getCurrentUrl().contains("facebook");
		Thread.sleep(2000);
		Assert.assertEquals(actualResult, true);
		
	}

}
