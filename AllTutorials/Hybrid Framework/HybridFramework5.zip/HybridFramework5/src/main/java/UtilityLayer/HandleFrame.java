package UtilityLayer;

import org.openqa.selenium.WebElement;

import BaseLayer.BaseClass;

public class HandleFrame extends BaseClass {

	public static void frame(String idorName) {
		driver.switchTo().frame(idorName);
	}

	public static void frame(int index) {
		driver.switchTo().frame(index);
	}

	public static void frame(WebElement wb) {
		driver.switchTo().frame(wb);
	}

	public static void parentFrame() {
		driver.switchTo().parentFrame();
	}

	public static void topFrame() {
		driver.switchTo().defaultContent();
	}

}
