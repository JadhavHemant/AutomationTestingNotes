package UtilityLayer;

import java.io.IOException;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ListenerSetUp extends ExtentReportsSetUp implements ITestListener {
	ExtentReports extentReports;
	ExtentTest extentTest;

	@Override
	public void onStart(ITestContext context) {
		// capture the project name
		String projectName = context.getSuite().getName();

		// start generating Extent Reports
		extentReports = ExtentReportsSetUp.setUp(projectName);
	}

	@Override
	public void onTestStart(ITestResult result) {
		// capture the test name
		String testCaseName = result.getMethod().getMethodName();

		// create test case inside the Extent Reports
		extentTest = extentReports.createTest("Test Case Started Name is " + testCaseName);
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		// capture the test case name
		String testcaseName = result.getMethod().getMethodName();
		// take screenshot

		String destinationPath = null;
		try {
			destinationPath = Screenshot.takeScreenshot("PassScreenshot", testcaseName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// generate log
		extentTest.log(Status.PASS, "Test Case Pass Name is " + testcaseName);
		// add screenshot reports
		extentTest.addScreenCaptureFromPath(destinationPath);

	}

	@Override
	public void onTestFailure(ITestResult result) {
		// capture the test case name
		String testcasename = result.getMethod().getMethodName();
		// capture screenshot
		String destinationPath = null;
		try {
			destinationPath = Screenshot.takeScreenshot("FailScreenshot", testcasename);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// generate log
		extentTest.log(Status.FAIL, "Test Case Fail name is " + testcasename);
		// add screenshot to the reports

		extentTest.addScreenCaptureFromPath(destinationPath);
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		String testCaseName = result.getMethod().getMethodName();
		extentTest.log(Status.SKIP, "Test case Skip name is " + testCaseName);
	}

	@Override
	public void onFinish(ITestContext context) {
		extentReports.flush();
	}

}
