package UtilityLayer;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateAndTime {

	// capture year
	public static String captureYear() {
		SimpleDateFormat simple = new SimpleDateFormat("yyyy");
		String year = simple.format(new Date());
		return year;
	}

	// capture month and year
	public static String captureMonthAndYear() {
//		SimpleDateFormat simple = new SimpleDateFormat("MMyyyy");
//		String monthYear = simple.format(new Date());
//		return monthYear;

		return new SimpleDateFormat("MMyyyy").format(new Date());
	}

	// capture date and time
	public static String captureDateAndTime() {
		return new SimpleDateFormat("ddMMyyyy_HHmmss").format(new Date());
	}
}
