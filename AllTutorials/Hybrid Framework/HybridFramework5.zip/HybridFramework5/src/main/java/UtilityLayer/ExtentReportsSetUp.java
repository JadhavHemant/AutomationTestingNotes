package UtilityLayer;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import BaseLayer.BaseClass;

public class ExtentReportsSetUp extends BaseClass {

	// create static method with ExtentReports return type and 1 String arguments

	public static ExtentReports setUp(String reportName) {
		ExtentReports extentReports = new ExtentReports();

		String destinationPath = System.getProperty("user.dir") + "//ExtentReports//" + DateAndTime.captureYear() + "//"
				+ DateAndTime.captureMonthAndYear() + "//" + reportName + DateAndTime.captureDateAndTime() + ".html";

		ExtentSparkReporter extentReporter = new ExtentSparkReporter(destinationPath);

		extentReports.attachReporter(extentReporter);

		return extentReports;
	}
}
