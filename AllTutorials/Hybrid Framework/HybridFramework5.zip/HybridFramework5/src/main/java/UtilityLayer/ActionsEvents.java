package UtilityLayer;

import BaseLayer.BaseClass;

public class ActionsEvents extends BaseClass{

	
}
