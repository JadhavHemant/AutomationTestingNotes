package TestLayer;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import BaseLayer.BaseClass;
import PageLayer.FramePage;

public class FramePageTest extends BaseClass {

	// 1: use pre condition annotation
	@BeforeTest
	public void setUp() {
		BaseClass.initialization();
	}
	// 2: create test case using @Test annotation

	@Test
	public void validateFrameExampleFunctionality() {
		FramePage framePage = new FramePage();

		framePage.frameExampleFunctionality("Amit abc", "Database Automation", "909090", "Pune India");
	}

	// 3: use post condition annotations
	@AfterTest
	public void tearDown() {
//		driver.quit();
	}

}
