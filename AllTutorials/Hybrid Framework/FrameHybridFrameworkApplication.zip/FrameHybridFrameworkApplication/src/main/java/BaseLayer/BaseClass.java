package BaseLayer;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass {

	// declare WebDriver globally as protected static
	protected static WebDriver driver;

	// create static initialization
	public static void initialization() {
		// connect browser

		// up casting
		driver = new ChromeDriver();
		// implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(45));
		// pageLoadTimeout
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(45));
		// maximize
		driver.manage().window().maximize();
		// deleteAllCookies
		driver.manage().deleteAllCookies();
		// open a url
		driver.get("https://praf002.github.io/");
	}
}
