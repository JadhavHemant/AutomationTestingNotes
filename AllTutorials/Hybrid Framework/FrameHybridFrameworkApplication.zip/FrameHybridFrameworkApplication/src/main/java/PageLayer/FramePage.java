package PageLayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayer.BaseClass;
import UtilityLayer.HandleDropDown;
import UtilityLayer.HandleFrame;
import UtilityLayer.Wait;

public class FramePage extends BaseClass {

	// step 1: find all object repository using Page Object model design pattern with Page Factory concept
	
	@FindBy(name="name")
	private WebElement fullName;
	
	@FindBy(name="GitHub")
	private WebElement GitHub;
	
	@FindBy(name="course")
	private WebElement course;
	
	@FindBy(name="mob")
	private WebElement mobile;
	
	@FindBy(name="add")
	private WebElement address;
	
	//frame name or id
	private static String mobFrame="mobileFrame";
	
	//frame id
	private static String checkboxFrame= "showcheckbox";
	
	//address frame index
	private static int addresFrame=1;
	
	@FindBy(id="toolframe")
	private WebElement toolFrame;
	
	//step 2 : initialize the object Repository using PageFactory.initElements() method by passing driver, this keyword in constructor
	public FramePage()
	{
		PageFactory.initElements(driver, this);
	}

	//step 3: create associated method for each and every object repository without entering test data.
	
	public void frameExampleFunctionality(String FullName,String CourseName,String MobileNo, String Address )
	{
		//Step 1: find the full name text box and enter the value
		Wait.sendKeys(fullName, FullName);
		
		//step 2: switch focus to mobile number frame
		HandleFrame.frame(mobFrame);
		
		//step 3: switch focus to checkbox frame
		HandleFrame.frame(checkboxFrame);
		
		//step 4: check on checkbox
		Wait.click(GitHub);
		
		//step 5: switch focus to top frame
		HandleFrame.defaultContent();
		
		//step 6: switch focus to address
		HandleFrame.frame(addresFrame);
		
		//step 7: switch focus to tool frame
		HandleFrame.frame(toolFrame);
		
		//step 8;  select the Database Automation values from drop down
		HandleDropDown.selectByVisibleText(course, CourseName);
		
		//step 9: switch focus to top frame
		HandleFrame.defaultContent();
		
		//step 10: switch focus to mobile frame
		HandleFrame.frame(mobFrame);
		
		//step 11: Enter the mobile numbers 
		Wait.sendKeys(mobile, MobileNo);

		//step 12: switch focus to top frame
		HandleFrame.defaultContent();
		
		//step 13: switch focus to address frame
		HandleFrame.frame(addresFrame);
	
		//step 14: enter address
		Wait.sendKeys(address, Address);
	}
	

}
