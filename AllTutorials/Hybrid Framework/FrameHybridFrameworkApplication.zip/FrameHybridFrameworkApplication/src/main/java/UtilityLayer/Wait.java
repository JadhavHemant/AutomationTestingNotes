package UtilityLayer;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import BaseLayer.BaseClass;

public class Wait extends BaseClass {

	// create static click method by passing WebElement arguments
	public static void click(WebElement wb) {
		// create object of WebDriverWait class by passing driver instance and Duration
		// in seconds
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		// use until() method from WebDriverWait class by passing
		// ExpectedConditions.elementToBeClickable() by passing WebElement instance and
		// then click() method

		wait.until(ExpectedConditions.elementToBeClickable(wb)).click();
	}

	// create static sendKeys method by passing WebElement arguments and String
	// arguments
	public static void sendKeys(WebElement wb, String value) {
		// create Object of WebDriverWait by passing WebDriver instance and Duration of
		// seconds
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		// use until() method from WebDriverWait class by passing ExpectedCondition dot
		// visibilityOf() method by passing WebElement instance and then sendKeys()
		// method by passing String arguemtns

		wait.until(ExpectedConditions.visibilityOf(wb)).sendKeys(value);

	}

}
