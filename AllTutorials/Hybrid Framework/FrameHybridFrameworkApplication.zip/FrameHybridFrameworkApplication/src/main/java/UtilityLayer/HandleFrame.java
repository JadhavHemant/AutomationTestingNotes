package UtilityLayer;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import BaseLayer.BaseClass;

public class HandleFrame extends BaseClass {

	// create frame() static method with String arguments
	public static void frame(String frameIdOrName) {
		// create object of WebDriverWait clas by passing driver instance and Duration
		// in seconds
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		// use until() method from WebDriverWait class by passing
		// ExpectedConditions.frameToBeAvailableAndSwitchToIt() by passing frame id or
		// name
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameIdOrName));

	}

	// create frame() static method with int arguments
	public static void frame(int frameindex) {
		// create Object of WebDriverWait by passing driver instance and Duration in
		// seconds
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		// use until() method from WebDriverWait class by passing ExpectecConditions dot
		// frameToBeAvailableAndSwitchToIt() by passing frame index
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameindex));

	}

	// create frame() static method with WebElement arguments
	public static void frame(WebElement frameWb) {
		// create object of WebDriverWait class by passing driver instance and Duration
		// in seconds

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		// use until() method from WebDriverWait class by passing ExpectedConditions dot
		// frameToBeAvailableAndSwitchToIt() and by passing frame web element

		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameWb));

	}

	// create parentFrame() method
	public static void parentFrame() {
		driver.switchTo().parentFrame();
	}

	// create defaultContent() method
	public static void defaultContent() {
		driver.switchTo().defaultContent();
	}

}
