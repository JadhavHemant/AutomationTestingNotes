package UtilityLayer;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import BaseLayer.BaseClass;

public class HandleDropDown extends BaseClass {

	// create static selectByVisibleText() method by passing WebElement and String
	// arguments
	public static void selectByVisibleText(WebElement wb, String value) {
		// create object of WebDriverWait by passing driver instance and Duration of  Seconds
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		// use until() method from WebDriverWait class by passing ExpectedCondition dot visiblityOf() method by passing WebElement instance
		WebElement wb1 = wait.until(ExpectedConditions.visibilityOf(wb));

		//create object of Select class by passsing visible WebElement instance
		Select sel=new Select(wb1);
		
		//use selectByVisibleText() method from Select class by passing string arguments
		sel.selectByVisibleText(value);
		
	}

	// create static selectByValue() method by passing WebElement and String  arguments
	public static void selectByValue(WebElement wb, String value)
	{
		
		// create object of WebDriverWait by passing driver instance and Duration of  Seconds
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		// use until() method from WebDriverWait class by passing ExpectedCondition dot visiblityOf() method by passing WebElement instance
		WebElement wb1 = wait.until(ExpectedConditions.visibilityOf(wb));

		//create object of Select class by passsing visible WebElement instance
		Select sel=new Select(wb1);
		
		//use selectByValue() method from Select by passing string arguments
		sel.selectByValue(value);
	}
	
	// create static selectByIndex() method by passing WebElement and String arguments
	public static void selectByIndex(WebElement wb, int index)
	{
		
		// create object of WebDriverWait by passing driver instance and Duration of  Seconds
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		// use until() method from WebDriverWait class by passing ExpectedCondition dot visiblityOf() method by passing WebElement instance
		WebElement wb1 = wait.until(ExpectedConditions.visibilityOf(wb));

		//create object of Select class by passsing visible WebElement instance
		Select sel=new Select(wb1);
		
		//use selectByIndex() method from Select class by passing index argumetns
		sel.selectByIndex(index);
		
	}
	
	


}
