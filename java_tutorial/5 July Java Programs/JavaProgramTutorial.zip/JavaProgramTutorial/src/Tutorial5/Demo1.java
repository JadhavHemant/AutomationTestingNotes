package Tutorial5;

public class Demo1 {

	public static void main(String[] args) {
		
		//loop for iterate the rows
				
		for(int i=1;i<=5;i++)
		{
			
			//loop for iterate the columns
						
			for(int j=1;j<=i;j++)
			{
				System.out.print("*" + " ");
			}
			
			System.out.println();
		}
		
		

	}

}
