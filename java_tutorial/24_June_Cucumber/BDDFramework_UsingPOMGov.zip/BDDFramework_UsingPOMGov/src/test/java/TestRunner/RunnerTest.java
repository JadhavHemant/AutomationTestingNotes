package TestRunner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(
		features = {"src/test/java/Features/TC_001_indiagov.feature"},
		glue = "StepDefinition",
		dryRun = false,
		monochrome = true,
		tags="@RegisterPage"
		
		)

public class RunnerTest extends AbstractTestNGCucumberTests{

}
