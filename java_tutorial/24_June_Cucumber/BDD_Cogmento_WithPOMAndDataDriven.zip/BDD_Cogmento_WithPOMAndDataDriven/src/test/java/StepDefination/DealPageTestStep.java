package StepDefination;

import PageLayer.DealPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DealPageTestStep {
	DealPage dealpage;
	String dealtitle;
	@When("user click on deals link")
	public void user_click_on_deals_link() {
		dealpage=new DealPage();
		dealpage.clickOnDealLink();
	    
	}

	@When("user click on deals page create button")
	public void user_click_on_deals_page_create_button() {
		dealpage.createDeal();
	   
	}

	@Then("user enter title and user select date as {int} and month and year as {string} and time as {string}")
	public void user_enter_title_and_user_select_date_as_and_month_and_year_as_and_time_as(int Date, String MonthAndYear, String Time) throws InterruptedException {
		  dealtitle="Deal1";
		dealpage.enterDealDetails(Date, MonthAndYear, Time, dealtitle);
	    
	}

	@Then("user click on save button of Deals Page")
	public void user_click_on_save_button_of_deals_page() {
		dealpage.userSaveDeal();
	    
	}

}
