package StepDefination;

import java.util.List;

import BaseLayer.BaseClass;
import PageLayer.LoginPage;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.AfterStep;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPageTestStep extends BaseClass {
	private LoginPage loginpage;

	@Given("user open a url in {string} browser")
	public void user_open_a_url_in_browser(String browsername) {
		BaseClass.initialization(browsername);

	}

	@When("user enter valid username and password")
	public void user_enter_valid_username_and_password(DataTable dataTable) {
		List<List<String>> list = dataTable.asLists();
		String email = list.get(0).get(0);
		String pass = list.get(0).get(1);
		loginpage = new LoginPage();
		loginpage.enterEmailAndPassword(email, pass);

	}

	@Then("user click on login button")
	public void user_click_on_login_button() {
		loginpage.clickOnLogin();

	}
	
	@AfterStep()
	public void tearDown() throws InterruptedException
	{
		Thread.sleep(3000);
	}

}
