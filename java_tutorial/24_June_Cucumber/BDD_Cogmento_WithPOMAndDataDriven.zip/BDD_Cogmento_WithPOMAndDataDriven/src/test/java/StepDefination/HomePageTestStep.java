package StepDefination;

import org.junit.jupiter.api.Assertions;

import PageLayer.HomePage;
import io.cucumber.java.en.When;

public class HomePageTestStep {
	private HomePage homepage;

	@When("user is on home page and validate title")
	public void user_is_on_home_page_and_validate_title() {

		homepage = new HomePage();
		String actualTitle = homepage.validateTitle();
		Assertions.assertEquals(actualTitle, "Cogmento CRM");
	}

	@When("user validate url")
	public void user_validate_url() {

		String actualurl = homepage.validateUrl();
		Assertions.assertEquals(actualurl.contains("cogmento"), true);
	}

}
