package StepDefination;

import PageLayer.ContactPage;
import io.cucumber.java.AfterStep;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ContactPageTestStep {
	public ContactPage contactpage;
	@When("user click on contact link")
	public void user_click_on_contact_link() {
		 contactpage= new ContactPage();
		 contactpage.clickOnContact();
		 
	    
	}

	@When("user click on create button")
	public void user_click_on_create_button() {
		contactpage.clickonCreateButtoninContactPage();
	    
	}

	@Then("user enter {string} , {string} and select {string}")
	public void user_enter_and_select(String firstname, String lastName, String status) throws InterruptedException {
		contactpage.enterDetails(firstname, lastName, status);
	    
	}

	@Then("user click on save button")
	public void user_click_on_save_button() throws InterruptedException {
		contactpage.clickOnSaveButtoninPage();
	   
	}
	
	/*@AfterStep()
	public void tearDown() throws InterruptedException
	{
		Thread.sleep(2000);
	}*/


}
