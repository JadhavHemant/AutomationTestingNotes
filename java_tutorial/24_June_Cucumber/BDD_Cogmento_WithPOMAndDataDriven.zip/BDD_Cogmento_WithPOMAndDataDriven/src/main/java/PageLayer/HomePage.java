package PageLayer;

import BaseLayer.BaseClass;

public class HomePage extends BaseClass {

	public String validateTitle() {
		String actualTitle=driver.getTitle();
		return actualTitle;

	}

	public String validateUrl() {
		String actualUrl=driver.getCurrentUrl();
		return actualUrl;


	}

}
