package PageLayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayer.BaseClass;
import UtilityLayer.Wait;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CompanyPage extends BaseClass {
	
	@FindBy(xpath="//span[text()='Companies']")
	private WebElement companylink;
	
	@FindBy(xpath="//button[text()='Create']")
	private WebElement createcompany;
	
	@FindBy(name="name")
	private WebElement companyname;
	
	@FindBy(name="url")
	private WebElement companywebsitename;
	
	@FindBy(name="address")
	private WebElement companyaddress;
	
	
	@FindBy(name="value")
	private WebElement companyemail;
	
	@FindBy(xpath="//button[text()='Save']")
	private WebElement companysavebutton;
	
	public CompanyPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	
	public void clickonCompanyLink() {
		Wait.click(companylink);
	   
	}

	
	public void clickCompanyPageCreateButton() {
		Wait.click(createcompany);
	    
	}

	
	public void userCompanydetails(String CName,String CWebsite, String CAddress, String CEmail) {
		Wait.sendKeys(companyname, CName);
		Wait.sendKeys(companywebsitename, CWebsite);
		Wait.sendKeys(companyaddress, CAddress);
		Wait.sendKeys(companyemail, CEmail);
	    
	}
	public void clickOnCompanySaveButton()
	{
		Wait.click(companysavebutton);
		
	}

	
	
	
	

}
