package PageLayer;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import BaseLayer.BaseClass;

import UtilityLayer.Wait;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DealPage extends BaseClass {
	@FindBy(xpath = "//span[text()='Deals']")
	private WebElement dealslink;

	@FindBy(xpath = "//button[text()='Create']")
	private WebElement createdealbutton;

	@FindBy(name = "title")
	private WebElement dealtitle;

	@FindBy(xpath = "//input[@class='calendarField']")
	private WebElement closedate;

	@FindBy(xpath = "//div[@class='react-datepicker__header react-datepicker__header--has-time-select']/child::div[@class='react-datepicker__current-month']")
	private WebElement currentmonthandyear;

	@FindBy(xpath = "//button[@aria-label='Next Month']")
	private WebElement nextbutton;

	@FindBys(@FindBy(xpath = "//div[@class='react-datepicker__month']/descendant::div[@role='option']"))
	private List<WebElement> datelist;

	@FindBys(@FindBy(xpath = "//div[@class='react-datepicker__time']/div/ul/li[@role='option']"))
	private List<WebElement> timelist;

	@FindBy(xpath = "//button[text()='Save']")
	private WebElement savedeal;

	public DealPage() {
		PageFactory.initElements(driver, this);
	}

	public void clickOnDealLink() {
		Wait.click(dealslink);
	}

	public void createDeal() {
		Wait.click(createdealbutton);

	}

	public void enterDealDetails(int date, String ExpectedMonthAndyear, String ExpectedTime, String DealTitle)
			throws InterruptedException {
		Wait.sendKeys(dealtitle, DealTitle);
		closedate.click();
		while (true) {
			String a = currentmonthandyear.getText();

			if (a.equalsIgnoreCase(ExpectedMonthAndyear)) {
				for (WebElement dates : datelist) {
					String b = dates.getText();
					String c = Integer.toString(date);
					if (b.equalsIgnoreCase(c)) {
						dates.click();
						break;
					}
				}
				break;
			} else {
				nextbutton.click();
			}
		}

		/*for (WebElement listtime : timelist) {
			String actualtimevalue = listtime.getText();
			if (actualtimevalue.equalsIgnoreCase(ExpectedTime)) {
				listtime.click();
			}
			break;
		}*/

	}

	public void userSaveDeal() {
		Wait.click(savedeal);
	}
}
