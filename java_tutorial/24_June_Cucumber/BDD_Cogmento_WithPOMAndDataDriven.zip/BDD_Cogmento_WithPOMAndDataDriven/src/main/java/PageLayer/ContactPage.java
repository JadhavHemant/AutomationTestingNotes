package PageLayer;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import BaseLayer.BaseClass;
import UtilityLayer.Wait;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ContactPage extends BaseClass {
	
	@FindBy(xpath="//span[text()='Contacts']")
	private WebElement contactslink;
	
	@FindBy(xpath="//button[text()='Create']")
	private WebElement createbutton;
	
	@FindBy(name="first_name")
	private WebElement fname;
	
	@FindBy(name="last_name")
	private WebElement lname;
	
	@FindBy(name="status")
	private WebElement statusdropdown;
	
	@FindBys(@FindBy(xpath="//div[@name='status']"))
	private List<WebElement> statuslist;
	
	
	@FindBy(xpath="//button[text()='Save']")
	private WebElement savebutton;
	
	public ContactPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	
	public void clickOnContact(){
		Wait.click(contactslink);
		
	    
	}

	
	public void clickonCreateButtoninContactPage() {
		Wait.click(createbutton);
	    
	}

	
	public void enterDetails(String Firstname, String LastName, String Status) throws InterruptedException {
		Wait.sendKeys(fname, Firstname);
		Wait.sendKeys(lname, LastName);
		//Thread.sleep(3000);
		Wait.click(statusdropdown);
		//Thread.sleep(3000);
		for(WebElement liststatus:statuslist)
		{
			String actualstatus=liststatus.getText();
			if(actualstatus.equalsIgnoreCase(Status))
			{
				Wait.click(liststatus);
			}
			break;
			
		}
		
	    
	}

	
	public void clickOnSaveButtoninPage() throws InterruptedException {
		//Thread.sleep(2000);
		Wait.click(savebutton);
	   
	}


	
	
	
	
	
	
	

}
