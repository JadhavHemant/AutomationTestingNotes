package Steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TaskPageTestSteps {
	@Given("user open url in {string} browser for tasks")
	public void user_open_url_in_browser_for_tasks(String browsername) {
	   
	}
	
	@When("user enter valid username and password for tasks page")
	public void user_enter_valid_username_and_password_for_tasks_page(io.cucumber.datatable.DataTable dataTable) {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
	    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
	    // Double, Byte, Short, Long, BigInteger or BigDecimal.
	    //
	    // For other transformations you can register a DataTableType.
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user click on taskpagelogin button")
	public void user_click_on_taskpagelogin_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user validate home page title for tasks page")
	public void user_validate_home_page_title_for_tasks_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user validate home page url for tasks page")
	public void user_validate_home_page_url_for_tasks_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user validate logo for tasks page")
	public void user_validate_logo_for_tasks_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Given("user verify user on tasks page")
	public void user_verify_user_on_tasks_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("user click on create new task")
	public void user_click_on_create_new_task() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("user enter title, select type, completion, select priority and status")
	public void user_enter_title_select_type_completion_select_priority_and_status() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user click on savetask button")
	public void user_click_on_savetask_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user delete task")
	public void user_delete_task() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user click on profile icon and click on logout menu for tasks page")
	public void user_click_on_profile_icon_and_click_on_logout_menu_for_tasks_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
}
