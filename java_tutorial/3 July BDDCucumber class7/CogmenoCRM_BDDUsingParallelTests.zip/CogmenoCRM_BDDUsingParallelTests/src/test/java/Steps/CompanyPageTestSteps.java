package Steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CompanyPageTestSteps {
	@Given("user open url in {string} browser forCompany")
	public void user_open_url_in_browser_forCompany(String browsername) {
	   
	}
	@When("user enter valid username and password for company page")
	public void user_enter_valid_username_and_password_for_company_page(io.cucumber.datatable.DataTable dataTable) {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
	    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
	    // Double, Byte, Short, Long, BigInteger or BigDecimal.
	    //
	    // For other transformations you can register a DataTableType.
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user click on companypagelogin button")
	public void user_click_on_companypagelogin_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user validate home page title for company page")
	public void user_validate_home_page_title_for_company_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user validate home page url for company page")
	public void user_validate_home_page_url_for_company_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user validate logo for company page")
	public void user_validate_logo_for_company_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Given("user verify user on companies page")
	public void user_verify_user_on_companies_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("user click on create new company")
	public void user_click_on_create_new_company() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("user enter name, website, address, industry, no.ofEmployees and select priority")
	public void user_enter_name_website_address_industry_no_of_employees_and_select_priority() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user click on savecompany button")
	public void user_click_on_savecompany_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user delete company")
	public void user_delete_company() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user click on profile icon and click on logout menu for company page")
	public void user_click_on_profile_icon_and_click_on_logout_menu_for_company_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
}
