package PageLayer;

import BaseLayer.BaseClass;

public class CompanyPage extends BaseClass{

}
