package PageLayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayer.BaseClass;
import Utility.Wait;

public class LoginPage extends BaseClass{
	@FindBy(name = "email")
	private WebElement email;

	@FindBy(name = "password")
	private WebElement password;

	@FindBy(xpath = "//div[text()='Login']")
	private WebElement loginbutton;

	public LoginPage() {
		PageFactory.initElements(getDriver(), this);
	}

	public void enterEmailAndPassword(String mail, String pass) {
		Wait.sendKeys(email, mail);
		Wait.sendKeys(password, pass);
	}

	public void clickOnLogin() {
		Wait.click(loginbutton);
	}
}
