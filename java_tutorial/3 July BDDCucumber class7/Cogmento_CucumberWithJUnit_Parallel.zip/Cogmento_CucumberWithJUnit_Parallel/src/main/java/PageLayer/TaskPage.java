package PageLayer;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import BaseLayer.BaseClass;
import Utility.Wait;
import io.cucumber.java.en.Then;

public class TaskPage extends BaseClass {
	@FindBy(xpath = "//span[text()='Tasks']")
	private WebElement tasklink;

	@FindBy(xpath = "//button[text()='Create']")
	private WebElement createbutton;
	
	@FindBy(name="title")
	private WebElement title;
	
	@FindBy(xpath="//div[@class='ui fluid selection dropdown']")
	private WebElement assignedto;
	
	@FindBy(xpath = "//label[text()='Due Date']/following-sibling::div/div/child::input")
	private WebElement duedate;

	@FindBy(xpath = "//div[@class='react-datepicker__header react-datepicker__header--has-time-select']/child::div[@class='react-datepicker__current-month']")
	private WebElement currentmonthandyear;

	@FindBy(xpath = "//button[@aria-label='Next Month']")
	private WebElement nextbutton;

	@FindBys(@FindBy(xpath = "//div[@class='react-datepicker__month']/descendant::div[@role='option']"))
	private List<WebElement> datelist;

	@FindBys(@FindBy(xpath = "//div[@class='react-datepicker__time']/div/ul/li[@class='react-datepicker__time-list-item ']"))
	private List<WebElement> timelist;
	
	@FindBy(xpath = "//button[text()='Save']")
	private WebElement tasksave;
	
	public TaskPage()
	{
		PageFactory.initElements(getDriver(), this);
	}
	
public void clickOnTaskLink() {
	
	Wait.click(tasklink);
	    
	}

public void clickOnCreateButton() {
    Wait.click(createbutton);
}


	public void enterTitleClickOnAssignedTo(String Title) {
		Wait.sendKeys(title, Title);
	    Wait.click(assignedto);
	    
	}

	
	public void enterTaskDetails(int date, String ExpectedMonthAndyear, String ExpectedTime)
			throws InterruptedException {
		
		duedate.click();
		while (true) {
			String a = currentmonthandyear.getText();

			if (a.equalsIgnoreCase(ExpectedMonthAndyear)) {
				for (WebElement dates : datelist) {
					String b = dates.getText();
					String c = Integer.toString(date);
					if (b.equalsIgnoreCase(c)) {
						dates.click();
						break;
					}
				}
				break;
			} else {
				nextbutton.click();
			}
		}

		Thread.sleep(5000);
		for (WebElement value : timelist) {
			String timeValue = value.getText();

			if (timeValue.equalsIgnoreCase(ExpectedTime)) {
				value.click();
				break;
			}
		}

	}


	
	public void clickOnSaveButtonOnTaskPage() {
	    Wait.click(tasksave);
	    
	}
	
	
	


}
