package Steps;

import PageLayer.ContactPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ContactPageTestStep {
	private ContactPage contactpage;

	@When("user click on contact link")
	public void user_click_on_contact_link() {
		contactpage = new ContactPage();
		contactpage.clickOnContact();

	}

	@When("user click on create button")
	public void user_click_on_create_button() {
		contactpage.clickonCreateButtoninContactPage();

	}

	@Then("user enter {string} , {string} and select {string}")
	public void user_enter_and_select(String Firstname, String Lastname, String Status) throws InterruptedException {
		contactpage.enterDetails(Firstname, Lastname, Status);

	}

	@Then("user click on save button in contact page")
	public void user_click_on_save_button_in_contact_page() throws InterruptedException {
		contactpage.clickOnSaveButtoninPage();
	}

	
	
	@Then("user will click on setting icon")
	public void user_will_click_on_setting_icon() throws InterruptedException {
		contactpage=new ContactPage(); 
		Thread.sleep(3000);
		contactpage.clickOnSettingIconInContactPage();

	}

	@Then("user will click on logout")
	public void user_will_click_on_logout() {
		contactpage.clickOnLogoutButton();
	}

}
