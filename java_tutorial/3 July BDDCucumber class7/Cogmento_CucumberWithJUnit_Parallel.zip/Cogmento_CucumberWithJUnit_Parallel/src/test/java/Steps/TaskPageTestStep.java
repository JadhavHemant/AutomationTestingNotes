package Steps;

import BaseLayer.BaseClass;
import PageLayer.TaskPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TaskPageTestStep extends BaseClass{
	private TaskPage taskpage;
	@When("user click on task link")
	public void user_click_on_task_link() {
		taskpage=new TaskPage();
		taskpage.clickOnTaskLink();
		
		
	    
	    
	}

@Then("user click on create button on task page")
public void user_click_on_create_button_on_task_page() {
	taskpage.clickOnCreateButton();
    
}

	@Then("user enter Title , click on assigned to")
	public void user_enter_title_click_on_assigned_to() {
		taskpage.enterTitleClickOnAssignedTo("ExecuteTestCase");
	    
	    
	}

	@Then("select due date as {int} and month and year as {string} and time as {string}")
	public void select_due_date_as_and_month_and_year_as_and_time_as(Integer Date1, String MontAndYear,String Time) throws InterruptedException 
	{
		taskpage.enterTaskDetails(Date1, MontAndYear, Time);
	
	}

	@Then("click on Save button on task page")
	public void click_on_save_button_on_task_page() {
		taskpage.clickOnSaveButtonOnTaskPage();
	    
	    
	}

	  
	    
	



}
