package Steps;

import org.junit.Assert;

import BaseLayer.BaseClass;
import PageLayer.HomePage;
import io.cucumber.java.en.When;

public class HomePageTestStep extends BaseClass {
	private HomePage homepage;

	@When("user is on home page and validate title")
	public void user_is_on_home_page_and_validate_title() {

		Assert.assertEquals(getDriver().getTitle(), "Cogmento CRM");
	}

	@When("user validate url")
	public void user_validate_url() {
		Assert.assertEquals(getDriver().getCurrentUrl().contains("cogmento"), true);

	}

	@When("validate logo")
	public void validate_logo() {
		homepage = new HomePage();

		Assert.assertEquals(homepage.validateLogo(), true);

	}
}
