package Steps;

import java.util.List;
import java.util.Map;

import PageLayer.CompanyPage;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CompanyPageTestStep {

	private CompanyPage companypage;
	@When("user click on company link")
	public void user_click_on_company_link() {
		companypage=new CompanyPage();
		companypage.clickonCompanyLink();
		
	   
	}

	@When("user click on company page create button")
	public void user_click_on_company_page_create_button() {
		companypage.clickCompanyPageCreateButton();
	    
	}

	@Then("user enter name, website,  address and email")
	public void user_enter_name_website_address_and_email(DataTable dataTable) {
		
		List<Map<String,String>> lists=dataTable.asMaps();
		String Cname=lists.get(0).get("name");
		String Cwebsite=lists.get(0).get("website");
		String Caddress=lists.get(0).get("address");
		String Cemail=lists.get(0).get("email");
		companypage.userCompanydetails(Cname, Cwebsite, Caddress, Cemail);
		
		
	}
	
	@Then("user click on Companies save button")
	public void user_click_on_companies_save_button() {
		companypage.clickOnCompanySaveButton();
	    
	}


}
