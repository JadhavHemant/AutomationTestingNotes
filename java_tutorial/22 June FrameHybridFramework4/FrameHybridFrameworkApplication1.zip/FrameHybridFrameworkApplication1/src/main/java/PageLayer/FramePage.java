package PageLayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayer.BaseClass;
import UtilityLayer.HandleFrame;
import UtilityLayer.Wait;

public class FramePage extends BaseClass {
	// Find OR with POM with Page Factory concept

	@FindBy(id = "name")
	private WebElement name;

	@FindBy(id = "add")
	private WebElement address;

	@FindBy(name = "Jenkins")
	private WebElement Jenkins;

	@FindBy(name = "TestNG")
	private WebElement TestNG;

	private static String AddressFrame = "mainframe";
	private static String checkboxFrame = "child1";

	// initialize the OR by using PageFactory.initElements by passing driver, this
	// in constructor
	public FramePage() {
		PageFactory.initElements(driver, this);
	}

	// create associated method for each and every OR without entering Test Data
	public void frameExampleFunctionality(String Name, String Address, String NewName, String NewAddress) {
//		step 1: find and enter name
		Wait.sendKeys(name, Name);

//		step 2: switch focus to address frame
		HandleFrame.frame(AddressFrame);

//		step 3: switch focus to checkbox frame
		HandleFrame.frame(checkboxFrame);

//		step 4: click on Jenkins checkbox

		Wait.click(Jenkins);
//		step 5: switch focus to parent frame
		HandleFrame.parentFrame();

//		step 6: find and enter address
		Wait.sendKeys(address, Address);

//		step 7:switch focus to top frame
		HandleFrame.defaultContent();

//		step 8: capture entered name , clear name and enter new name
		String captureName = Wait.getAttribute(name, "value");
		System.out.println(captureName);

		Wait.clear(name);

		Wait.sendKeys(name, NewName);

		// step 9:switch focus to address frame
		HandleFrame.frame(AddressFrame);

//		step 10: capture address and clear address and enter new address
		String captureAdd = Wait.getAttribute(address, "value");
		System.out.println(captureAdd);

		Wait.clear(address);

		Wait.sendKeys(address, NewAddress);

//		step 11: switch focus to checkbox frame 
		HandleFrame.frame(checkboxFrame);

//		step 12: unselect the Jenkins checkbox
		Wait.click(Jenkins);

//		step 13: select the TestNG checkbox
		Wait.click(TestNG);

	}

}
