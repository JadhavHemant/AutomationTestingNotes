package UtilityLayer;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import BaseLayer.BaseClass;

public class HandleAlert extends BaseClass {

	// create static accept() method
	public static void accept() {
		// create object of WebDriverWait class by passing driver, Duration in seconds
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		// use until() method from WebDriverWait class by passing ExpectedConditions dot
		// alertIsPresent() method and then accept
		wait.until(ExpectedConditions.alertIsPresent()).accept();

	}

	// create static dismiss() method
	public static void dismiss() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.alertIsPresent()).dismiss();
	}

	// create static getText() method with String return type
	public static String getText() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		return wait.until(ExpectedConditions.alertIsPresent()).getText();
	}

	// create static sendKeys() method with String arguments
	public static void sendKeys(String value) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.alertIsPresent()).sendKeys(value);
	}

}
