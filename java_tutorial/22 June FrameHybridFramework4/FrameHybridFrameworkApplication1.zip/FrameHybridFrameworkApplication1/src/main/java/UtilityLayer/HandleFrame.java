package UtilityLayer;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import BaseLayer.BaseClass;

public class HandleFrame extends BaseClass{

	//create static frame() method by passing string id or name args
	public static void frame(String idOrName)
	{
		WebDriverWait wait =new WebDriverWait(driver, Duration.ofSeconds(30));
		
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(idOrName));
		
	}
	
	//create static frame() method by passing int index args
	public static void frame(int frameindex)
	{
		WebDriverWait wait =new WebDriverWait(driver,Duration.ofSeconds(30));
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameindex));
	}
	
	//create static frame() method by passing WebElement args
	public static void frame(WebElement frameWb)
	{
		WebDriverWait wait =new WebDriverWait(driver, Duration.ofSeconds(30));
		
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameWb));
	}
	
	//create static parentFrame() method
	public static void parentFrame()
	{
		driver.switchTo().parentFrame();
	}
	
	//create static defaultContent() method
	public static void defaultContent()
	{
		driver.switchTo().defaultContent();
	}
	
	
}

