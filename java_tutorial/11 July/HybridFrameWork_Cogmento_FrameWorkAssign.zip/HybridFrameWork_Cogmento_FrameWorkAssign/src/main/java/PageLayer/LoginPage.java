package PageLayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayer.BaseClass;

public class LoginPage extends BaseClass{
	//find all object repository with page object model with Factory
	
	@FindBy(name="email")
	private WebElement email;
	
	@FindBy(name="password")
	private WebElement password;
	
	@FindBy(xpath="//div[text()='Login']")
	private WebElement login;
	
	
	//initilization of object Repository with PageFactory dot initElement() method in cunstructor
	
	public LoginPage()
	{
		PageFactory.initElements(driver,this);
	}
	
	//create associated methods for each and every object repository without entering test data
	
	public void loginFunctionality(String Email,String Password)
	{
		email.sendKeys(Email);
		password.sendKeys(Password);
		login.click();
	
	
	

}
}
