package PageLayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayer.BaseClass;

public class ContactPage extends BaseClass{
	
     //Find all object Repository with Page object model with PageFactory
	
	@FindBy(xpath="//a[@href='/contacts']")
	private WebElement contactlink;
	
	@FindBy(xpath="//a[@href='/contacts/new']")
	private WebElement createbutton;
	
	@FindBy(name="first_name")
	private WebElement Firstname;
	
	@FindBy(name="last_name")
	private WebElement Lastname;
	
	@FindBy(name="middle_name")
	private WebElement Middlename;
	
	@FindBy(xpath="//button[text()='Save']")
	private WebElement savebutton;
	
	public ContactPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public void  contactPageFunctionality(String firstname, String lastname,String middlename)
	{
		contactlink.click();
		createbutton.click();
		Firstname.sendKeys(firstname);
		Lastname.sendKeys(lastname);
		Middlename.sendKeys(middlename);
		savebutton.click();
		
	}
	
}
