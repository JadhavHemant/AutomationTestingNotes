package TestLayer;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayer.BaseClass;
import PageLayer.HomePage;

public class HomePage_Test extends BaseClass {
	
	private static HomePage homePage;
	
	@Test(priority=1)
	
	public void validateLogo()
	{
		
		 homePage=new HomePage();
		
		boolean actuallogo=homePage.checkLogoStatus();
		 
		 Assert.assertEquals(actuallogo, true);
	}
	@Test(priority=2)
	public void validateTitle()
	{
		String actualTitle=homePage.getHomePageTitle();
		
		Assert.assertEquals(actualTitle, "Cogmento CRM");
	}
	
	@Test(priority=3)
	
	public void validateurl()
	{
		String actualUrl=homePage.getHomePageurl();
		
		Assert.assertEquals(actualUrl.contains("cogmento"),true);
	}
	
	

}
