package TestLayer;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import BaseLayer.BaseClass;
import PageLayer.LoginPage;

public class LoginPage_Test extends BaseClass{
	
	@Parameters({"browsername"})
	@BeforeTest
	public void setUp(String browsername)
	{
		BaseClass.initilization(browsername);
		
	}
	
	
	@Test
	public void validateLoginFunctionality()
	{
		LoginPage loginPage=new LoginPage();
		
		loginPage.loginFunctionality("prafulp1010@gmail.com", "Pr@ful0812");
	
	}
	
	@AfterTest
	public void tearDown()
	{
		driver.quit();
	}
	
	
	
	
	

}
