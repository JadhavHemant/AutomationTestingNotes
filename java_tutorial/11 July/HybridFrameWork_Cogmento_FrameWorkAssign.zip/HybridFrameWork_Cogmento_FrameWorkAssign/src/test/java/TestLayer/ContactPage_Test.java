package TestLayer;

import org.testng.annotations.Test;

import BaseLayer.BaseClass;
import PageLayer.ContactPage;

public class ContactPage_Test extends BaseClass {

	@Test

	public void validateContactPageFunctionality()

	{
             ContactPage contactPage=new ContactPage();
             
             contactPage.contactPageFunctionality("Advait", "Kulkarni","Amit");
             
             
	}

}
