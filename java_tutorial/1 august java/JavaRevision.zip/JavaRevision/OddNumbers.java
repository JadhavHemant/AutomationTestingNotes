package JavaRevision;

public class OddNumbers {

	public static void main(String[] args) {
		// print odd 1 to 20 numbers
		System.out.println("Odd Numbers between 1 to 20 are:");
		for(int i=1; i<=20; i++)
		{
			if(i%2!=0)
			{
				System.out.println(i);
			}
		}
			

	}

}
